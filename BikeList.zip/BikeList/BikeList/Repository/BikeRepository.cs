﻿using BikeList.Helper;
using BikeList.Models;
using BikeList.Repository.Interface;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;

namespace BikeList.Repository
{
    public class BikeRepository : IBikeRepository
    {
        private readonly IConfiguration _config;
        private HelperClass _helper;
        public BikeRepository(IConfiguration config)
        {
            _config = config;
            _helper = new HelperClass();
        }
        private List<BikeModels> bikelist = new List<BikeModels>();
        private List<BikeModels> GenerateBikeList()
        {
            for (var i = 0; i <= 100; i++)
            {
                if (_config.GetValue<int>($"Bike{i + 1}:BikeId") > 0)
                {
                    BikeModels bike = new BikeModels();
                    bike.BikeId = _config.GetValue<int>($"bike{i + 1}:BikeId");
                    bike.ModelName = _config.GetValue<string>($"bike{i + 1}:ModelName");
                    bike.Company = _config.GetValue<string>($"bike{i + 1}:Company");
                    bike.Price = _config.GetValue<int>($"bike{i + 1}:Price");
                    bikelist.Add(bike);
                }
                else
                    break;
            }
            return bikelist;
        }

        public List<BikeModels> GetAllBikes()
        {
            return GenerateBikeList();
        }

        public List<BikeModels> Search(string search)
        {
            var bikes = GenerateBikeList();
            var bike = bikes.Where(x => x.ModelName.StartsWith(search) || search == null).ToList();
            return bike;
        }

        public List<BikeModels> AddNewBike(BikeModels bike)
         {
             var bikes = GenerateBikeList();
             bike.BikeId = bikes.Count + 1;
             bikes.Add(bike);
            //_helper.AddtoJson(bike);
            _helper.AddtoJson<BikeModels>(bike);
            return bikes;
         }

        public List<BikeModels> EditBikes(int bikeId)
        {
            var bikes = GenerateBikeList();
            var bike = bikes.Find(x => x.BikeId == bikeId);
            bike.ModelName = "edited " + bike.ModelName;
            return bikes;
        }

        public bool DeleteBikes(int bikeId, out List<BikeModels>  bikes)
        {
            bikes = GenerateBikeList();
            bikes.Remove(bikes.Find(x => x.BikeId == bikeId));
            var bike = bikes.Find(x => x.BikeId == bikeId);
            if(bike == null)
            {
                _helper.RemoveFromJson(bikeId, "Bike");
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
