﻿using BikeList.Helper;
using BikeList.Models;
using BikeList.Repository.Interface;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;

namespace BikeList.Repository
{
    public class CompanyRepository : ICompanyRepository
    {
        private readonly IConfiguration _config;
        private HelperClass _helper;
        public CompanyRepository(IConfiguration config)
        {
            _config = config;
            _helper = new HelperClass();
        }
        private List<CompanyModels> companylist = new List<CompanyModels>();
        private List<CompanyModels> GenerateCompanyList()
        {
            for (var i = 0; i <= 100; i++)
            {
                if (_config.GetValue<int>($"Company{i + 1}:CompanyId") > 0)
                {
                    CompanyModels company = new CompanyModels();
                    company.CompanyId = _config.GetValue<int>($"company{i + 1}:CompanyId");
                    company.CompanyName = _config.GetValue<string>($"company{i + 1}:CompanyName");
                    company.City = _config.GetValue<string>($"company{i + 1}:City");
                    companylist.Add(company);
                }
                else
                    break;
            }
            return companylist;
        }

        public List<CompanyModels> GetAllCompanies()
        {
            return GenerateCompanyList();
        }

        public List<CompanyModels> Search(string search)
        {
            var companies = GenerateCompanyList();
            var company = companies.Where(x => x.CompanyName.StartsWith(search) || search == null).ToList();
            return company;
        }

        public List<CompanyModels> AddNewCompany(CompanyModels company)
         {
             var companies = GenerateCompanyList();
            company.CompanyId = companies.Count + 1;
             companies.Add(company);
            //_helper.AddtoJson(company);
            _helper.AddtoJson<CompanyModels>(company);
            return companies;
         }

        public List<CompanyModels> EditCompanies(int companyId)
        {
            var companies = GenerateCompanyList();
            var company = companies.Find(x => x.CompanyId == companyId);
            company.CompanyName = "edited " + company.CompanyName;
            return companies;
        }

        public bool DeleteCompanies(int companyId, out List<CompanyModels>  companies)
        {
            companies = GenerateCompanyList();
            companies.Remove(companies.Find(x => x.CompanyId == companyId));
            var company = companies.Find(x => x.CompanyId == companyId);
            if(company == null)
            {
                _helper.RemoveFromJson(companyId, "Company");
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
