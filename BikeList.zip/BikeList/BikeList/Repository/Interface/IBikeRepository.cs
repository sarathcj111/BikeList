﻿using BikeList.Models;
using System.Collections.Generic;

namespace BikeList.Repository.Interface
{
    public interface IBikeRepository
    {
       List<BikeModels> AddNewBike(BikeModels bikeModels);
        List<BikeModels> GetAllBikes();
        List<BikeModels> EditBikes(int bikeId);
        bool DeleteBikes(int bikeId, out List<BikeModels> bikes);
        List<BikeModels> Search(string search);
    }
}