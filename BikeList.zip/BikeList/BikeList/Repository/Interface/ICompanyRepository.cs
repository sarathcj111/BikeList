﻿using BikeList.Models;
using System.Collections.Generic;

namespace BikeList.Repository.Interface
{
    public interface ICompanyRepository
    {
        List<CompanyModels> AddNewCompany(CompanyModels companyModels);
        List<CompanyModels> GetAllCompanies();
        List<CompanyModels> EditCompanies(int companyId);
        bool DeleteCompanies(int bikeId, out List<CompanyModels> company);
        List<CompanyModels> Search(string search);
    }
}
