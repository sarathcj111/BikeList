﻿using BikeList.Models;
using BikeList.Repository.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace BikeList.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IBikeRepository _IBikeRepository;

        public HomeController(ILogger<HomeController> logger, IBikeRepository iBikeRepository)
        {
            _logger = logger;
            _IBikeRepository = iBikeRepository;
        }

        public IActionResult Index()
        { 
        /*public IActionResult Index(string search)
        {
            if(search == "CompanyA")
            {
                HomeController data = new HomeController(); 
                TempData["mydata"] = data;
                return RedirectToAction("Index", "CompanyA");
            }
            else if(search == "CompanyB")
            {
                return RedirectToAction("Index", "CompanyB");
            }
            else
                return RedirectToAction("Index", "CompanyB");*/
        return View();
        }
        public IActionResult OpenAddBikePage()
        {
            return View("AddBike");
        }

        public IActionResult AddBike(BikeModels bike)
        {
            var bikes = _IBikeRepository.AddNewBike(bike);
            return View("Index", bikes);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
