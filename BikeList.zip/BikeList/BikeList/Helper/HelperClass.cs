﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using BikeList.Models;

namespace BikeList.Helper
{
    public class HelperClass
    {
        //public void AddtoJson(BikeModels bike)
        public void AddtoJson<T>(T help)
        {
            var appSettingsPath = Path.Combine(System.IO.Directory.GetCurrentDirectory(), "appsettings.json");
            var json = File.ReadAllText(appSettingsPath);

            var jsonSettings = new JsonSerializerSettings();
            jsonSettings.Converters.Add(new ExpandoObjectConverter());
            jsonSettings.Converters.Add(new StringEnumConverter());

            dynamic config = JsonConvert.DeserializeObject<ExpandoObject>(json, jsonSettings);

            //dynamic newBike = JsonConvert.DeserializeObject<ExpandoObject>(JsonConvert.SerializeObject(bike), jsonSettings);
            dynamic newinput = JsonConvert.DeserializeObject<ExpandoObject>(JsonConvert.SerializeObject(help), jsonSettings);

            var expando = config as IDictionary<string, object>;
            //expando.Add($"Bike{bike.BikeId}", newBike);
            expando.Add($"{help}", newinput);

            var newJson = JsonConvert.SerializeObject(config, Formatting.Indented, jsonSettings);

            File.WriteAllText(appSettingsPath, newJson);
        }

        /*public void AddtoJson(CompanyModels company)
        {
            var appSettingsPath = Path.Combine(System.IO.Directory.GetCurrentDirectory(), "appsettings.json");
            var json = File.ReadAllText(appSettingsPath);

            var jsonSettings = new JsonSerializerSettings();
            jsonSettings.Converters.Add(new ExpandoObjectConverter());
            jsonSettings.Converters.Add(new StringEnumConverter());

            dynamic config = JsonConvert.DeserializeObject<ExpandoObject>(json, jsonSettings);

            dynamic newCompany = JsonConvert.DeserializeObject<ExpandoObject>(JsonConvert.SerializeObject(company), jsonSettings);

            var expando = config as IDictionary<string, object>;
            expando.Add($"Company{company.CompanyId}", newCompany);

            var newJson = JsonConvert.SerializeObject(config, Formatting.Indented, jsonSettings);

            File.WriteAllText(appSettingsPath, newJson);
        }*/

        public void RemoveFromJson(int Id, string type)
        {
            var appSettingsPath = Path.Combine(System.IO.Directory.GetCurrentDirectory(), "appsettings.json");
            var json = File.ReadAllText(appSettingsPath);

            var jsonSettings = new JsonSerializerSettings();
            jsonSettings.Converters.Add(new ExpandoObjectConverter());
            jsonSettings.Converters.Add(new StringEnumConverter());

            dynamic config = JsonConvert.DeserializeObject<ExpandoObject>(json, jsonSettings);

            var expando = config as IDictionary<string, object>;
            expando.Remove($"{type}{Id}");

            var newJson = JsonConvert.SerializeObject(config, Formatting.Indented, jsonSettings);

            File.WriteAllText(appSettingsPath, newJson);
        }
    }
}
