﻿using BikeList.Models;
using BikeList.Repository.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace BikeList.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IBikeRepository _IBikeRepository;
        private readonly ICompanyRepository _ICompanyRepository;

        public HomeController(ILogger<HomeController> logger, IBikeRepository iBikeRepository, ICompanyRepository iCompanyRepository)
        {
            _logger = logger;
            _IBikeRepository = iBikeRepository;
            _ICompanyRepository = iCompanyRepository;
        }
        public IActionResult Index()
        {
            var bikes = _IBikeRepository.GetAllBikes();
            return View(bikes);
        }

        public IActionResult Search(string searchby, string search)
        {
            if(searchby == "Bike")
            {
                var bikeList = _IBikeRepository.Search(search);
                return View("Index", bikeList);
            }
            else
            {
                var companyList = _ICompanyRepository.Search(search);
                return View("Index", companyList);
            }
        }

        public IActionResult EditBikes(int bikeId)
        {
            var bikeList = _IBikeRepository.EditBikes(bikeId);
            return View("Index", bikeList);
        }

        public IActionResult DeleteBikes(int bikeId)
        {
            var isbike = _IBikeRepository.DeleteBikes(bikeId, out List<BikeModels> bikes);

            return View("Index", bikes);
        }
        public IActionResult OpenAddBikePage()
        {
            var companies = _ICompanyRepository.GetAllCompanies();
            ViewBag.ListItem = companies;
            return View("AddBike");
        }

        public IActionResult AddBike(BikeModels bike)
        {
            var bikes = _IBikeRepository.AddNewBike(bike);
            return View("Index", bikes);
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}