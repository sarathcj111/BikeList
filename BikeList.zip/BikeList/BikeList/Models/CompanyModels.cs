﻿namespace BikeList.Models
{
    public class CompanyModels
    {
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string City { get; set; }
    }
}
