﻿using BikeList.Models;
using BikeList.Repository.Interface;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace BikeList.Repository
{
    public class BikeRepository : IBikeRepository
    {
        private readonly IConfiguration _config;
        public BikeRepository(IConfiguration config)
        {
            _config = config;
        }
        private List<BikeModels> bikelist = new List<BikeModels>();
        private List<BikeModels> GenerateBikeList()
        {
            for (var i = 0; i < 3; i++)
            {
                BikeModels bike = new BikeModels();
                bike.Id = _config.GetValue<int>($"bike{i + 1}:Id");
                bike.ModelName = _config.GetValue<string>($"bike{i + 1}:ModelName");
                bike.Company = _config.GetValue<string>($"bike{i + 1}:Company");
                bike.Price = _config.GetValue<int>($"bike{i + 1}:Price");
                bikelist.Add(bike);
            }
            return bikelist;
        }

        public List<BikeModels> GetAllBikes()
        {
            return GenerateBikeList();
        }

        public List<BikeModels> AddNewBike(BikeModels bike)
         {
             var bikes = GenerateBikeList();
             bike.Id = bikes.Count + 1;
             bikes.Add(bike);
             return bikes;
         }

        public List<BikeModels> EditBikes(int bikeId)
        {
            var bikes = GenerateBikeList();
            var bike = bikes.Find(x => x.Id == bikeId);
            bike.ModelName = "edited " + bike.ModelName;
            return bikes;
        }

        public bool DeleteBikes(int bikeId, out List<BikeModels>  bikes)
        {
            bikes = GenerateBikeList();
            bikes.Remove(bikes.Find(x => x.Id == bikeId));
            var bike = bikes.Find(x => x.Id == bikeId);
            if(bike == null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
