﻿using BikeList.Models;
using BikeList.Repository.Interface;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace BikeList.Controllers
{
    public class CompanyAController : Controller
    {
        private readonly IBikeRepository _IBikeRepository;

        public CompanyAController(IBikeRepository iBikeRepository)
        {
            _IBikeRepository = iBikeRepository;
        }
        public IActionResult Index()
        {
            var bikes = _IBikeRepository.GetAllBikes();
            return View(bikes);
        }

        public IActionResult EditBikes(int bikeId)
        {
            var bikeList = _IBikeRepository.EditBikes(bikeId);
            return View("Index", bikeList);
        }

        public IActionResult DeleteBikes(int bikeId)
        {
            var bikeList = _IBikeRepository.DeleteBikes(bikeId, out List<BikeModels> bikes);
            return View("Index", bikes);
        }
    }
}
