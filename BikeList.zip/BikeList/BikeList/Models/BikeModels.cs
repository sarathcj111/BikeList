﻿namespace BikeList.Models
{
    public class BikeModels
    {
        public int Id { get; set; }
        public string ModelName { get; set; }
        public string Company { get; set; }
        public int Price { get; set; } 
    }
}
